import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { 
  ShoppingCart, 
  Package, 
  Store, 
  TrendingUp, 
  Search, 
  Bot, 
  ShieldCheck, 
  Rocket,
  Globe,
  MessageSquare,
  MessageCircle,
  CheckCircle,
  ArrowRight 
} from "lucide-react";
import { Link } from "react-router-dom";

const ecommerceServices = [
  {
    icon: ShoppingCart,
    title: "Amazon Account Management",
    description: "Complete Amazon seller management including catalog optimization, A+ content, brand registry, and account health monitoring.",
    features: [
      "Product listing optimization",
      "A+ Content & Brand Store",
      "Inventory management",
      "Customer review management",
      "Account health monitoring",
      "Policy compliance",
    ],
    color: "text-[#FF9900]",
    bgColor: "bg-[#FF9900]/10",
    borderColor: "border-[#FF9900]/20",
  },
  {
    icon: Package,
    title: "Flipkart Account Management",
    description: "End-to-end Flipkart seller services with product listings, ad campaigns, performance optimization, and seller score improvement.",
    features: [
      "Catalog listing & optimization",
      "Flipkart Ads management",
      "Seller score optimization",
      "Order fulfillment support",
      "Return management",
      "Performance analytics",
    ],
    color: "text-[#047BD5]",
    bgColor: "bg-[#047BD5]/10",
    borderColor: "border-[#047BD5]/20",
  },
  {
    icon: Store,
    title: "Meesho Account Management",
    description: "Grow your Meesho presence with optimized catalog, competitive pricing, and efficient order management for maximum visibility.",
    features: [
      "Bulk product uploads",
      "Pricing optimization",
      "Quality score management",
      "Order processing",
      "Customer query handling",
      "Growth analytics",
    ],
    color: "text-[#F43397]",
    bgColor: "bg-[#F43397]/10",
    borderColor: "border-[#F43397]/20",
  },
  {
    icon: TrendingUp,
    title: "Ads & PPC Management",
    description: "ROI-focused advertising campaigns across Amazon, Flipkart, and other platforms. Maximize visibility while optimizing your ad spend.",
    features: [
      "Campaign strategy & setup",
      "Keyword research & bidding",
      "ACoS optimization",
      "A/B testing",
      "Budget management",
      "Performance reporting",
    ],
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/20",
  },
  {
    icon: Search,
    title: "Listing & SEO Optimization",
    description: "Data-driven keyword research, compelling product copy, and SEO-optimized listings that rank higher and convert better.",
    features: [
      "Keyword research",
      "Title & bullet optimization",
      "Backend keyword setup",
      "Enhanced content",
      "Image optimization",
      "Competition analysis",
    ],
    color: "text-accent",
    bgColor: "bg-accent/10",
    borderColor: "border-accent/20",
  },
  {
    icon: Bot,
    title: "AI Automation for Sellers",
    description: "Leverage cutting-edge AI tools for inventory, pricing, customer support automation using n8n, WhatsApp bots, and CRM systems.",
    features: [
      "Inventory automation",
      "Dynamic pricing",
      "WhatsApp chatbots",
      "CRM integration",
      "Order notifications",
      "AI-powered insights",
    ],
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/20",
  },
  {
    icon: ShieldCheck,
    title: "Account Reinstatement",
    description: "Expert handling of suspended accounts, policy violations, and appeal writing with a 90% success rate.",
    features: [
      "Suspension analysis",
      "Root cause identification",
      "Plan of Action writing",
      "Appeal submission",
      "Follow-up management",
      "Prevention strategy",
    ],
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    borderColor: "border-destructive/20",
  },
  {
    icon: Rocket,
    title: "Brand Growth Strategy",
    description: "Complete brand building from trademark registration to brand registry setup and long-term growth consulting.",
    features: [
      "Trademark assistance",
      "Brand Registry setup",
      "Brand Store creation",
      "Growth roadmap",
      "Market expansion",
      "Competitor analysis",
    ],
    color: "text-accent",
    bgColor: "bg-accent/10",
    borderColor: "border-accent/20",
  },
];

const webServices = [
  {
    icon: Globe,
    title: "WordPress Website",
    description: "Professional WordPress websites with modern designs, SEO optimization, and easy content management for your business.",
    features: [
      "Custom theme design",
      "Mobile responsive",
      "SEO optimized",
      "Plugin integration",
      "Content management",
      "Performance optimization",
    ],
    color: "text-[#21759B]",
    bgColor: "bg-[#21759B]/10",
    borderColor: "border-[#21759B]/20",
  },
  {
    icon: ShoppingCart,
    title: "Shopify Website",
    description: "Custom Shopify stores with beautiful themes, payment integration, and conversion-optimized layouts for e-commerce success.",
    features: [
      "Custom store design",
      "Product setup",
      "Payment gateway",
      "Shipping setup",
      "App integrations",
      "Conversion optimization",
    ],
    color: "text-[#96BF48]",
    bgColor: "bg-[#96BF48]/10",
    borderColor: "border-[#96BF48]/20",
  },
  {
    icon: MessageSquare,
    title: "WhatsApp Automation",
    description: "Automated WhatsApp messaging for customer support, order updates, marketing campaigns, and lead nurturing.",
    features: [
      "Auto-reply setup",
      "Order notifications",
      "Broadcast messages",
      "Lead capture",
      "Customer support bot",
      "Analytics & reports",
    ],
    color: "text-[#25D366]",
    bgColor: "bg-[#25D366]/10",
    borderColor: "border-[#25D366]/20",
  },
  {
    icon: MessageCircle,
    title: "AI Chatbot Integration",
    description: "Smart AI chatbots for 24/7 customer support, lead generation, automated sales assistance, and customer engagement.",
    features: [
      "24/7 customer support",
      "Lead qualification",
      "FAQ automation",
      "Multi-language support",
      "CRM integration",
      "Analytics dashboard",
    ],
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/20",
  },
];

const Services = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Hero */}
        <section className="py-20 md:py-28 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-hero" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
          
          <div className="container relative z-10 px-4">
            <div className="max-w-3xl mx-auto text-center">
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                Our Services
              </span>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                Complete E-commerce{" "}
                <span className="text-gradient">Management Solutions</span>
              </h1>
              <p className="text-muted-foreground text-lg md:text-xl mb-8">
                From listing optimization to full automation — we provide everything you need 
                to dominate Indian e-commerce marketplaces.
              </p>
              <Button variant="hero" size="xl" asChild>
                <Link to="/contact">
                  Get Started
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* E-commerce Services Grid */}
        <section className="py-20 md:py-32 bg-gradient-dark">
          <div className="container px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                E-commerce Management
              </span>
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
                Marketplace <span className="text-gradient">Account Management</span>
              </h2>
              <p className="text-muted-foreground text-lg">
                Complete management solutions for Amazon, Flipkart, Meesho, and more.
              </p>
            </div>

            <div className="space-y-16">
              {ecommerceServices.map((service, index) => (
                <div 
                  key={service.title}
                  className={`grid lg:grid-cols-2 gap-8 lg:gap-16 items-center ${
                    index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                    <div className={`w-14 h-14 rounded-2xl ${service.bgColor} flex items-center justify-center mb-6`}>
                      <service.icon className={`w-7 h-7 ${service.color}`} />
                    </div>
                    <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
                      {service.title}
                    </h2>
                    <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                      {service.description}
                    </p>
                    <Button variant="outline" asChild>
                      <Link to="/contact">
                        Learn More
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </Button>
                  </div>

                  <div className={`${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                    <div className={`p-8 rounded-2xl bg-gradient-card border ${service.borderColor}`}>
                      <h3 className="font-display font-semibold text-foreground mb-6">
                        What's Included
                      </h3>
                      <div className="grid sm:grid-cols-2 gap-4">
                        {service.features.map((feature) => (
                          <div key={feature} className="flex items-center gap-3">
                            <CheckCircle className={`w-5 h-5 ${service.color} shrink-0`} />
                            <span className="text-muted-foreground text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Web & Automation Services */}
        <section className="py-20 md:py-32">
          <div className="container px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
                Web & Automation
              </span>
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
                <span className="text-gradient">Digital Solutions</span> for Modern Business
              </h2>
              <p className="text-muted-foreground text-lg">
                Websites, automation, and AI-powered tools to supercharge your business.
              </p>
            </div>

            <div className="space-y-16">
              {webServices.map((service, index) => (
                <div 
                  key={service.title}
                  className={`grid lg:grid-cols-2 gap-8 lg:gap-16 items-center ${
                    index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                    <div className={`w-14 h-14 rounded-2xl ${service.bgColor} flex items-center justify-center mb-6`}>
                      <service.icon className={`w-7 h-7 ${service.color}`} />
                    </div>
                    <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
                      {service.title}
                    </h2>
                    <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                      {service.description}
                    </p>
                    <Button variant="outline" asChild>
                      <Link to="/contact">
                        Learn More
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </Button>
                  </div>

                  <div className={`${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                    <div className={`p-8 rounded-2xl bg-gradient-card border ${service.borderColor}`}>
                      <h3 className="font-display font-semibold text-foreground mb-6">
                        What's Included
                      </h3>
                      <div className="grid sm:grid-cols-2 gap-4">
                        {service.features.map((feature) => (
                          <div key={feature} className="flex items-center gap-3">
                            <CheckCircle className={`w-5 h-5 ${service.color} shrink-0`} />
                            <span className="text-muted-foreground text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 md:py-32 relative overflow-hidden bg-gradient-dark">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-accent/10" />
          <div className="container relative z-10 px-4 text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              Not Sure Which Service You Need?
            </h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
              Book a free consultation and let our experts analyze your business 
              to recommend the best growth strategy.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="xl" asChild>
                <Link to="/contact">
                  Get Free Consultation
                </Link>
              </Button>
              <Button variant="whatsapp" size="xl" asChild>
                <a href="https://wa.me/918987374635" target="_blank" rel="noopener noreferrer">
                  WhatsApp Us
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Services;