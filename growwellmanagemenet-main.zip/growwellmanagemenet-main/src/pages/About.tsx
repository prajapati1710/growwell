import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Target, Users, Lightbulb, Award, ArrowRight, Globe, Code, Palette } from "lucide-react";
import { Link } from "react-router-dom";
const values = [{
  icon: Target,
  title: "Results-Driven",
  description: "We measure success by your growth. Every strategy is designed to deliver measurable ROI."
}, {
  icon: Users,
  title: "Client-First",
  description: "Your success is our success. We treat every client's business like our own."
}, {
  icon: Lightbulb,
  title: "Innovation",
  description: "We stay ahead with cutting-edge AI tools and automation to give you competitive advantage."
}, {
  icon: Award,
  title: "Excellence",
  description: "We maintain the highest standards in everything we do, from communication to execution."
}];
const About = () => {
  return <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Hero */}
        <section className="py-20 md:py-28 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-hero" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
          
          <div className="container relative z-10 px-4">
            <div className="max-w-3xl mx-auto text-center">
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                About Us
              </span>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                Your Growth Partner in{" "}
                <span className="text-gradient">E-commerce</span>
              </h1>
              <p className="text-muted-foreground text-lg md:text-xl">
                GrowWell Management is a modern e-commerce growth agency helping sellers 
                dominate marketplaces with expert management and AI-powered automation.
              </p>
            </div>
          </div>
        </section>

        {/* Owner Section */}
        <section className="py-20 md:py-32 bg-gradient-dark">
          <div className="container px-4">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              {/* Owner Image */}
              <div className="relative order-2 lg:order-1">
                <div className="absolute -inset-4 bg-gradient-primary rounded-3xl blur-2xl opacity-20" />
                <div className="relative aspect-square max-w-md mx-auto rounded-3xl overflow-hidden glass-strong p-2">
                  <div className="w-full h-full rounded-2xl bg-gradient-to-br from-primary/20 via-secondary to-accent/20 flex items-center justify-center">
                    <div className="text-center p-8">
                      <div className="w-32 h-32 mx-auto rounded-full bg-gradient-primary flex items-center justify-center mb-6">
                        <span className="font-display text-5xl font-bold text-primary-foreground">VP</span>
                      </div>
                      <p className="text-muted-foreground text-sm">Founder & CEO</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Owner Info */}
              <div className="order-1 lg:order-2">
                <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
                  Meet Our Founder
                </span>
                <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
                  <span className="text-gradient">Varun Prajapati</span>
                </h2>
                <p className="text-xl text-foreground font-medium mb-6">
                  Founder & CEO, GrowWell Management
                </p>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    With over 3 years of hands-on experience in website designing and digital solutions, 
                    Varun Prajapati founded GrowWell Management with a vision to empower Indian sellers 
                    in the competitive e-commerce landscape.
                  </p>
                  <p>
                    His expertise spans across WordPress, Shopify, and custom web development, 
                    combined with a deep understanding of marketplace dynamics on Amazon, Flipkart, 
                    and Meesho. Varun believes in leveraging technology and automation to help 
                    businesses scale efficiently.
                  </p>
                  <p>
                    Under his leadership, GrowWell Management has grown to serve 50+ sellers across India, 
                    helping them achieve consistent growth through strategic account management, 
                    AI-powered automation, and data-driven marketing solutions.
                  </p>
                </div>

                {/* Expertise Tags */}
                <div className="mt-8 flex flex-wrap gap-3">
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm">
                    <Globe className="w-4 h-4" />
                    Web Development
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent text-sm">
                    <Code className="w-4 h-4" />
                    E-commerce Expert
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm">
                    <Palette className="w-4 h-4" />
                    UI/UX Design
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-20 md:py-32">
          <div className="container px-4">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              <div>
                <h2 className="font-display text-3xl md:text-4xl font-bold mb-6">
                  Our <span className="text-gradient">Story</span>
                </h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    GrowWell Management was born from a simple observation: Indian e-commerce sellers 
                    were struggling to keep up with the complexity of managing multiple marketplace accounts 
                    while trying to grow their business.
                  </p>
                  <p>
                    We started with a mission to democratize e-commerce success. 
                    We believed that every seller — whether a small wholesaler in Delhi or a manufacturer 
                    in Gujarat — deserves access to the same level of expertise and tools that big brands use.
                  </p>
                  <p>
                    Today, we've helped 50+ sellers across India scale their e-commerce operations. 
                    From Amazon to Flipkart, Meesho to JioMart, we provide comprehensive management 
                    services that let sellers focus on what they do best — sourcing and selling great products.
                  </p>
                  <p>
                    What sets us apart is our commitment to innovation. We integrate AI and automation 
                    tools like n8n, WhatsApp chatbots, and CRM systems to make e-commerce operations truly scalable.
                  </p>
                </div>
              </div>

              {/* Stats */}
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-primary rounded-3xl blur-2xl opacity-20" />
                <div className="relative glass-strong rounded-3xl p-8 md:p-10">
                  <h3 className="font-display text-2xl font-bold text-foreground mb-8">
                    By The Numbers
                  </h3>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="text-center p-4 rounded-xl bg-secondary/50">
                      <p className="font-display text-3xl md:text-4xl font-bold text-primary mb-1">50+</p>
                      <p className="text-muted-foreground text-sm">Sellers Managed</p>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-secondary/50">
                      <p className="font-display text-3xl md:text-4xl font-bold text-accent mb-1">1500+</p>
                      <p className="text-muted-foreground text-sm">Product Listings Optimized</p>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-secondary/50">
                      <p className="font-display text-3xl md:text-4xl font-bold text-primary mb-1">98%</p>
                      <p className="text-muted-foreground text-sm">Client Retention</p>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-secondary/50">
                      <p className="font-display text-3xl md:text-4xl font-bold text-accent mb-1">5+</p>
                      <p className="text-muted-foreground text-sm">Marketplaces</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-20 md:py-32 bg-gradient-dark">
          <div className="container px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
                Our <span className="text-gradient">Values</span>
              </h2>
              <p className="text-muted-foreground text-lg">
                The principles that guide everything we do at GrowWell Management.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map(value => <div key={value.title} className="p-6 rounded-2xl bg-gradient-card border border-border hover:border-primary/30 transition-all duration-300">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <value.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {value.description}
                  </p>
                </div>)}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 md:py-32 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-accent/10" />
          <div className="container relative z-10 px-4 text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              Ready to Write Your Success Story?
            </h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
              Join 50+ sellers who trust GrowWell Management with their e-commerce growth.
            </p>
            <Button variant="hero" size="xl" asChild>
              <Link to="/contact">
                Start Your Journey
                <ArrowRight className="w-5 h-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>;
};
export default About;