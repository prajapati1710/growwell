import { Users, Bot, TrendingUp, Wallet, HeadphonesIcon, CheckCircle } from "lucide-react";
const features = [{
  icon: Users,
  title: "Dedicated Account Managers",
  description: "Get a personal account manager who understands your business and provides hands-on support."
}, {
  icon: Bot,
  title: "AI-Powered Automation",
  description: "Leverage cutting-edge AI tools for inventory, pricing, and customer engagement automation."
}, {
  icon: TrendingUp,
  title: "Proven Growth Strategy",
  description: "Data-driven strategies that have helped 50+ sellers increase their revenue by 3x on average."
}, {
  icon: Wallet,
  title: "Affordable Pricing",
  description: "Flexible pricing plans designed for Indian sellers. Start small, scale as you grow."
}, {
  icon: HeadphonesIcon,
  title: "Indian Seller Support",
  description: "Hindi & English support from a team that understands Indian marketplace dynamics."
}];
const WhyUsSection = () => {
  return <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/30 to-background" />
      
      <div className="container relative z-10 px-4">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <div>
            <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
              Why Choose Us
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
              Why <span className="text-gradient">GrowWell</span> is Different
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              We're not just another agency. We're your growth partners with a deep understanding of Indian e-commerce ecosystem and cutting-edge automation capabilities.
            </p>

            {/* Features List */}
            <div className="space-y-6">
              {features.map((feature, index) => <div key={feature.title} className="flex gap-4 items-start group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-foreground mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>)}
            </div>
          </div>

          {/* Right Content - Stats Card */}
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-primary rounded-3xl blur-2xl opacity-20" />
            <div className="relative glass-strong rounded-3xl p-8 md:p-10">
              <h3 className="font-display text-2xl font-bold text-foreground mb-8">
                Our Track Record
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50">
                  <CheckCircle className="w-6 h-6 text-primary shrink-0" />
                  <div>
                    <p className="font-display text-2xl font-bold text-foreground">50+</p>
                    <p className="text-muted-foreground text-sm">Sellers Successfully Managed</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50">
                  <CheckCircle className="w-6 h-6 text-primary shrink-0" />
                  <div>
                    <p className="font-display text-2xl font-bold text-foreground">₹1500 +</p>
                    <p className="text-muted-foreground text-sm">Product Listings Optimized</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50">
                  <CheckCircle className="w-6 h-6 text-primary shrink-0" />
                  <div>
                    <p className="font-display text-2xl font-bold text-foreground">3x Average</p>
                    <p className="text-muted-foreground text-sm">Sales Growth for Our Clients</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50">
                  <CheckCircle className="w-6 h-6 text-primary shrink-0" />
                  <div>
                    <p className="font-display text-2xl font-bold text-foreground">98%</p>
                    <p className="text-muted-foreground text-sm">Client Retention Rate</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50">
                  <CheckCircle className="w-6 h-6 text-accent shrink-0" />
                  <div>
                    <p className="font-display text-2xl font-bold text-foreground">90%</p>
                    <p className="text-muted-foreground text-sm">Account Reinstatement Success</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default WhyUsSection;