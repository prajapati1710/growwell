import { Phone, ClipboardCheck, Settings, TrendingUp, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const steps = [
  {
    number: "01",
    icon: Phone,
    title: "Book Free Call",
    description: "Schedule a free 30-minute consultation with our e-commerce experts to discuss your goals.",
  },
  {
    number: "02",
    icon: ClipboardCheck,
    title: "Account Audit",
    description: "We analyze your current performance, identify opportunities, and create a custom growth plan.",
  },
  {
    number: "03",
    icon: Settings,
    title: "We Optimize & Automate",
    description: "Our team implements strategies, optimizes listings, sets up ads, and automates operations.",
  },
  {
    number: "04",
    icon: TrendingUp,
    title: "Sales Growth",
    description: "Watch your sales grow while we handle the day-to-day management of your e-commerce business.",
  },
];

const HowItWorksSection = () => {
  return (
    <section className="py-20 md:py-32 bg-gradient-dark relative overflow-hidden">
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--foreground)) 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }}
      />

      <div className="container relative z-10 px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            How It Works
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Your Journey to{" "}
            <span className="text-gradient">E-commerce Success</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            A simple 4-step process to transform your online selling business.
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connection Line - Desktop */}
          <div className="hidden lg:block absolute top-24 left-[12.5%] right-[12.5%] h-0.5 bg-gradient-to-r from-primary/50 via-primary to-primary/50" />

          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              {/* Step Card */}
              <div className="text-center group">
                {/* Step Number Circle */}
                <div className="relative mx-auto mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-card border border-border flex items-center justify-center mx-auto group-hover:border-primary/50 transition-colors relative z-10">
                    <step.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground font-bold text-sm z-20">
                    {step.number}
                  </div>
                </div>

                <h3 className="font-display font-semibold text-xl text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>

              {/* Arrow - Mobile/Tablet */}
              {index < steps.length - 1 && (
                <div className="lg:hidden flex justify-center my-4">
                  <ArrowRight className="w-6 h-6 text-primary rotate-90" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <Button variant="accent" size="xl" asChild>
            <a href="/contact">
              Start Your Growth Journey
              <ArrowRight className="w-5 h-5" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
