import { 
  ShoppingCart, 
  Package, 
  Store, 
  TrendingUp, 
  Search, 
  Bot, 
  ShieldCheck, 
  Rocket,
  Globe,
  MessageSquare,
  MessageCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const services = [
  {
    icon: ShoppingCart,
    title: "Amazon Account Management",
    description: "Complete Amazon seller management including catalog optimization, A+ content, and brand registry support.",
    color: "text-[#FF9900]",
    bgColor: "bg-[#FF9900]/10",
  },
  {
    icon: Package,
    title: "Flipkart Account Management",
    description: "End-to-end Flipkart seller services with product listings, ad campaigns, and performance optimization.",
    color: "text-[#047BD5]",
    bgColor: "bg-[#047BD5]/10",
  },
  {
    icon: Store,
    title: "Meesho Account Management",
    description: "Grow your Meesho catalog with optimized listings, pricing strategies, and order management.",
    color: "text-[#F43397]",
    bgColor: "bg-[#F43397]/10",
  },
  {
    icon: TrendingUp,
    title: "Ads & PPC Management",
    description: "ROI-focused advertising campaigns across all platforms. Maximize visibility while minimizing ACoS.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Search,
    title: "Listing & SEO Optimization",
    description: "Keyword research, compelling copy, and SEO-optimized listings that rank higher and convert better.",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: Bot,
    title: "AI Automation for Sellers",
    description: "Automate inventory, pricing, customer support with AI tools including n8n, WhatsApp bots, and CRM.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: ShieldCheck,
    title: "Account Reinstatement",
    description: "Expert handling of suspended accounts, policy violations, and appeal writing with high success rate.",
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
  {
    icon: Rocket,
    title: "Brand Growth Strategy",
    description: "Complete brand building including trademark registration, brand registry, and growth consulting.",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
];

const webServices = [
  {
    icon: Globe,
    title: "WordPress Website",
    description: "Professional WordPress websites with modern designs, SEO optimization, and easy content management.",
    color: "text-[#21759B]",
    bgColor: "bg-[#21759B]/10",
  },
  {
    icon: ShoppingCart,
    title: "Shopify Website",
    description: "Custom Shopify stores with beautiful themes, payment integration, and conversion-optimized layouts.",
    color: "text-[#96BF48]",
    bgColor: "bg-[#96BF48]/10",
  },
  {
    icon: MessageSquare,
    title: "WhatsApp Automation",
    description: "Automated WhatsApp messaging for customer support, order updates, and marketing campaigns.",
    color: "text-[#25D366]",
    bgColor: "bg-[#25D366]/10",
  },
  {
    icon: MessageCircle,
    title: "AI Chatbot Integration",
    description: "Smart AI chatbots for 24/7 customer support, lead generation, and automated sales assistance.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
];

const ServicesSection = () => {
  return (
    <section className="py-20 md:py-32 bg-gradient-dark relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="container relative z-10 px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Our Services
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Everything You Need to{" "}
            <span className="text-gradient">Scale Your E-commerce</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            From account setup to full automation — we handle it all so you can focus on your business.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="group p-6 rounded-2xl bg-gradient-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-card hover:-translate-y-1"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`w-12 h-12 rounded-xl ${service.bgColor} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <service.icon className={`w-6 h-6 ${service.color}`} />
              </div>
              <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                {service.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>

        {/* Web & Automation Services Section */}
        <div className="mt-20">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
              Web & Automation
            </span>
            <h3 className="font-display text-2xl md:text-3xl lg:text-4xl font-bold mb-4">
              <span className="text-gradient">Digital Solutions</span> for Modern Business
            </h3>
            <p className="text-muted-foreground text-lg">
              Websites, automation, and AI-powered tools to supercharge your business.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {webServices.map((service, index) => (
              <div
                key={service.title}
                className="group p-6 rounded-2xl bg-gradient-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-card hover:-translate-y-1"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className={`w-12 h-12 rounded-xl ${service.bgColor} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className={`w-6 h-6 ${service.color}`} />
                </div>
                <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                  {service.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button variant="hero" size="lg" asChild>
            <Link to="/services">
              View All Services
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
