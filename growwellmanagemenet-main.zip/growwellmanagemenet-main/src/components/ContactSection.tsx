import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Mail, MessageCircle, Send, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
const ContactSection = () => {
  const {
    toast
  } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSubmitting(false);
    setIsSubmitted(true);
    toast({
      title: "Message Sent!",
      description: "We'll get back to you within 24 hours."
    });
  };
  return <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/30 via-background to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container relative z-10 px-4">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left Content */}
          <div>
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Get Started
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
              Ready to <span className="text-gradient">Grow Your Sales?</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Book a free consultation with our e-commerce experts. No obligations, just actionable insights for your business.
            </p>

            {/* Contact Methods */}
            <div className="space-y-4 mb-8">
              <a href="https://wa.me/918987374635" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl bg-[#25D366]/10 border border-[#25D366]/20 hover:border-[#25D366]/50 transition-colors group">
                <div className="w-12 h-12 rounded-xl bg-[#25D366] flex items-center justify-center shrink-0">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-foreground group-hover:text-[#25D366] transition-colors">
                    WhatsApp Us
                  </p>
                  <p className="text-muted-foreground text-sm">
                    Quick response within minutes
                  </p>
                </div>
              </a>

              <a href="tel:+918987374635" className="flex items-center gap-4 p-4 rounded-xl bg-primary/10 border border-primary/20 hover:border-primary/50 transition-colors group">
                <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    Call Us Now
                  </p>
                  <p className="text-muted-foreground text-sm">
                    +91 8987374635 
                  </p>
                </div>
              </a>

              <a href="mailto:contact@growwellmanagement.com" className="flex items-center gap-4 p-4 rounded-xl bg-accent/10 border border-accent/20 hover:border-accent/50 transition-colors group">
                <div className="w-12 h-12 rounded-xl bg-gradient-accent flex items-center justify-center shrink-0">
                  <Mail className="w-6 h-6 text-accent-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-foreground group-hover:text-accent transition-colors">
                    Email Us
                  </p>
                  <p className="text-muted-foreground text-sm">
                    contact@growwellmanagement.com
                  </p>
                </div>
              </a>
            </div>
          </div>

          {/* Right Content - Form */}
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-primary rounded-3xl blur-2xl opacity-10" />
            <div className="relative glass-strong rounded-3xl p-8 md:p-10">
              <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                Get Free Consultation
              </h3>
              <p className="text-muted-foreground mb-6">
                Fill the form and we'll reach out within 24 hours.
              </p>

              {isSubmitted ? <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-primary" />
                  </div>
                  <h4 className="font-display text-xl font-semibold text-foreground mb-2">
                    Thank You!
                  </h4>
                  <p className="text-muted-foreground">
                    We've received your message and will contact you soon.
                  </p>
                </div> : <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Input placeholder="Your Name" required className="bg-secondary/50 border-border focus:border-primary" />
                    </div>
                    <div>
                      <Input type="tel" placeholder="Phone Number" required className="bg-secondary/50 border-border focus:border-primary" />
                    </div>
                  </div>
                  <div>
                    <Input type="email" placeholder="Email Address" required className="bg-secondary/50 border-border focus:border-primary" />
                  </div>
                  <div>
                    <Input placeholder="Which marketplace do you sell on?" className="bg-secondary/50 border-border focus:border-primary" />
                  </div>
                  <div>
                    <Textarea placeholder="Tell us about your business and goals..." rows={4} className="bg-secondary/50 border-border focus:border-primary resize-none" />
                  </div>
                  <Button type="submit" variant="hero" size="lg" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Sending..." : <>
                        Send Message
                        <Send className="w-4 h-4" />
                      </>}
                  </Button>
                </form>}
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default ContactSection;