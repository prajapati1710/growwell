import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How much does it cost to work with GrowWell?",
    answer: "Our pricing is flexible and designed for Indian sellers. We offer packages starting from ₹15,000/month depending on the services you need and the number of products/accounts you have. We also offer revenue-sharing models for select clients. Contact us for a custom quote.",
  },
  {
    question: "Do you work on a revenue sharing model?",
    answer: "Yes! For qualified sellers with consistent monthly sales, we offer a revenue-sharing model where we charge a small percentage of your incremental sales growth instead of a fixed fee. This aligns our incentives with your success.",
  },
  {
    question: "Which e-commerce platforms do you support?",
    answer: "We provide full management services for Amazon India, Flipkart, Meesho, JioMart, and Snapdeal. We also offer consulting services for international marketplaces like Amazon US, UAE, and UK.",
  },
  {
    question: "Is this legal and safe for my seller account?",
    answer: "Absolutely! All our strategies and practices are 100% compliant with marketplace policies. We never use black-hat techniques that could risk your account. Our team stays updated with the latest policy changes to ensure your account remains in good standing.",
  },
  {
    question: "How long does it take to see results?",
    answer: "Most clients start seeing improvements within 2-4 weeks after we optimize their listings and launch campaigns. Significant growth typically happens within 2-3 months. Results vary based on your product category, competition, and starting point.",
  },
  {
    question: "Can you help with suspended accounts?",
    answer: "Yes, we have a 90% success rate in reinstating suspended Amazon and Flipkart accounts. Our team specializes in appeal writing, plan of action creation, and working with marketplace teams to resolve issues.",
  },
  {
    question: "What if I'm just starting out with no sales history?",
    answer: "Perfect! We love working with new sellers. We'll help you with product selection, listing creation, launch strategy, and building your initial sales momentum. Our starter packages are designed specifically for new sellers.",
  },
  {
    question: "Do I need to provide access to my seller account?",
    answer: "Yes, we'll need appropriate access to manage your account effectively. We use secure methods and can work with limited permissions if preferred. All access is protected with two-factor authentication and we sign NDAs to protect your data.",
  },
];

const FAQSection = () => {
  return (
    <section className="py-20 md:py-32 bg-gradient-dark relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="container relative z-10 px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            FAQs
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Frequently Asked{" "}
            <span className="text-gradient">Questions</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Everything you need to know about working with GrowWell Management.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-gradient-card border border-border rounded-xl px-6 data-[state=open]:border-primary/30 transition-colors"
              >
                <AccordionTrigger className="text-left font-display font-semibold text-foreground hover:text-primary py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
